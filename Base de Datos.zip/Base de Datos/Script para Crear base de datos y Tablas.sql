-- Crear la base de datos
--CREATE DATABASE SistemaBancario;

-- Usar la base de datos recién creada
USE SistemaBancario;

-- Crear la tabla Tipos
CREATE TABLE Tipos (
    IdTipo INT PRIMARY KEY IDENTITY(1,1),
    DescripcionTipo NVARCHAR(255),
);

-- Crear la tabla Cliente
CREATE TABLE Clientes (
    IdCliente INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(255),
    Identificacion NVARCHAR(20),
    Telefono NVARCHAR(15),
    IdTipo INT, -- Esta columna se usará para la relación con la tabla Tipos
    FOREIGN KEY (IdTipo) REFERENCES Tipos(IdTipo)
);


-- Crear la tabla Productos
CREATE TABLE Productos (
    IdProducto INT PRIMARY KEY IDENTITY(1,1),
    DescripcionProducto NVARCHAR(255),
    IdCliente INT, -- Esta columna se usará para la relación con la tabla Cliente
    FOREIGN KEY (IdCliente) REFERENCES Clientes(IdCliente)
);

-- Crear la tabla Saldos
CREATE TABLE Saldos (
    IdSaldo INT PRIMARY KEY IDENTITY(1,1),
    Accion VARCHAR(50) NOT NULL,
    Intereses INT,
    Depositos INT,
	Retiros INT,
	Total INT,
    IdCliente INT, -- Esta columna se usará para la relación con la tabla Cliente
    FOREIGN KEY (IdCliente) REFERENCES Clientes(IdCliente)
);

CREATE TABLE Usuarios (
    UsuarioID INT PRIMARY KEY IDENTITY(1,1),
    Nombre VARCHAR(50) NOT NULL,
	Contrasena VARCHAR(50) NOT NULL
);