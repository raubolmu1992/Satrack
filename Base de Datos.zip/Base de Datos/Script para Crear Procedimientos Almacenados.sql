USE SistemaBancario
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


alter procedure [dbo].[usp_registrar](
 @Nombre              varchar(60),
 @Identificacion       varchar(60),
 @Telefono             varchar(60),
 @DescripcionTipo       varchar(60),    
 @DescripcionProducto   varchar(60)

)
as
begin

Declare @ValTipo INT
Declare @ValCliente INT



--Insertar Tipos 
insert into Tipos(DescripcionTipo)
values
(
@DescripcionTipo
)

SET @ValTipo = (SELECT TOP 1 IdTipo FROM Tipos ORDER BY IdTipo DESC)


--Insertar Clientes 
insert into Clientes(Nombre,Identificacion,Telefono,IdTipo)
values
(
@Nombre,
@Identificacion,
@Telefono,
@ValTipo
)


SET @ValCliente = (SELECT TOP 1 IdCliente FROM Clientes ORDER BY IdCliente DESC)


--Insertar Productos 
insert into Productos(DescripcionProducto,IdCliente)
values
(
@DescripcionProducto,
@ValCliente
)


end

go

--Listar Usuarios
alter procedure [dbo].[usp_ListarUsuarios](
@Usuario varchar(60),
@Contrasena varchar(60)
)
as
begin

Select * from Usuarios where Nombre = @Usuario and Contrasena = @Contrasena

end


-- usp_listar 
go
alter procedure usp_listar
as
begin
WITH TotalesPorCliente AS (
    SELECT
        C.IdCliente,
        C.Nombre,
        C.Identificacion,
        C.Telefono,
        COALESCE(T.DescripcionTipo, 'Sin Tipo') AS DescripcionTipo,
        COALESCE(P.DescripcionProducto, 'Sin Producto') AS DescripcionProducto,
        COALESCE(MAX(S.Accion), 'Sin transacciones') AS Accion,
        SUM(CASE WHEN S.Accion = 'Depositar' THEN S.Depositos ELSE 0 END) AS Depositos,
        SUM(CASE WHEN S.Accion = 'Retirar' THEN S.Retiros ELSE 0 END) AS TotalRetiros
    FROM Clientes C
    LEFT JOIN Saldos S ON C.IdCliente = S.IdCliente
    LEFT JOIN Tipos T ON T.IdTipo = C.IdTipo
    LEFT JOIN Productos P ON P.IdCliente = C.IdCliente
    WHERE S.Accion IN ('Depositar', 'Retirar') OR S.Accion IS NULL
    GROUP BY C.IdCliente, C.Nombre, C.Identificacion, C.Telefono, T.DescripcionTipo, P.DescripcionProducto
)
SELECT
    T.IdCliente,
    T.Nombre,
    T.Identificacion,
    T.Telefono,
    T.DescripcionTipo,
    T.DescripcionProducto,
    T.Accion,
    T.Depositos,
    (T.Depositos - T.TotalRetiros) AS Total
FROM TotalesPorCliente T


	FOR JSON PATH
end


go

alter procedure usp_obtener
 @Identificacion int
as
begin

select c.Nombre, c.Identificacion, c.Telefono, t.DescripcionTipo, p.DescripcionProducto  from clientes c , Tipos t, Productos p--, Saldos s
	where t.IdTipo = c.IdTipo and p.IdCliente = c.IdCliente --and s.IdCliente = c.IdCliente
	and c.Identificacion = @Identificacion
	FOR JSON PATH
end


go
alter procedure [dbo].[usp_Depositar](
 @Accion      varchar(60),
 @Intereses   varchar(60),
 @Depositos      varchar(60),
 @Retiros      varchar(60),
 @Total       varchar(60),    
 @IdCliente   varchar(60)
)
as
begin
Declare @ValIdCliente INT
SET @ValIdCliente = (SELECT  IdCliente FROM Clientes where Identificacion = @IdCliente)


--Insertar Saldos
insert into Saldos(Accion, Intereses, Depositos, Retiros, Total, IdCliente)
values
(
@Accion,
@Intereses,
@Depositos,
@Retiros,
@Total,
@ValIdCliente
)

end